CREATE package body mypackage is
procedure print1(v_empno in varchar,v_ename in varchar) is
  
  cursor cur is select emp.empno,emp.ename from emp where emp.empno = v_empno; 
  c cur%rowtype;
  begin
    open cur;
    fetch cur into c;
    dbms_output.put_line(c.empno||c.ename);
    
  end;
  
  procedure print2(v_ename in varchar) is
  
  cursor cur is select empno,ename from emp where emp.ename = v_ename;
  c cur%rowtype;
  begin
    open cur;
    fetch cur into c;
    dbms_output.put_line(c.empno||c.ename);
    
  end;
  
procedure print3(v_empno in varchar,v_sal in varchar) is
  begin
    update emp set esal = v_sal  where empno = v_empno;
    if sql%found then
      dbms_output.put_line('更新成功');
      commit;
      else
        rollback;
         dbms_output.put_line('更新失败');
        end if;
  end;
procedure print4(v_empno in varchar) is
  begin
    delete emp where empno = v_empno;
    if sql%found then
      dbms_output.put_line('删除成功');
      commit;
      else
        rollback;
        dbms_output.put_line('删除失败');
        end if;
    
  end;
procedure print5(v_empno in varchar,v_ename in varchar) is
  begin
    insert into emp (emp.empno,emp.ename)values (v_empno,v_ename);
    if SQL%FOUND then
      dbms_output.put_line('插入成功');
      commit;
      else
        rollback;
        dbms_output.put_line('插入成功');
        end if;
  end; 
 
end mypackage;
/
