CREATE package mypackage is
procedure print1(v_ename in varchar); 
procedure print1(v_empno in varchar,v_ename in varchar);
procedure print3(v_empno in varchar,v_sal in varchar);
procedure print4(v_empno in varchar);
procedure print5(v_empno in varchar,v_ename in varchar);

end mypackage;
/
